from argparse import Action, ArgumentParser
from botocore.client import ClientError
import boto3
import time

known_drivers = ['local', 's3']
class DriverAction(Action):
    def __call__(self, parser, namespace, values, option_string=None):
        driver, destination = values
        if driver.lower() not in known_drivers:
            parser.error("Unkown driver. Available drivers are 'local' & 's3'")
        namespace.driver = driver.lower()
        namespace.destination = destination

def create_parser():
    parser = ArgumentParser()
    parser.add_argument('url', help="URL of the PostgreSQL database to backup")
    parser.add_argument('--driver', '-d', help="how & where to store the backup",
            nargs=2,
            action=DriverAction,
            metavar=('driver', 'destination'),
            required=True)
    return parser

def create_bucket(bucketn):
    s3 = boto3.resource('s3')
    try:
        s3.meta.client.head_bucket(Bucket=bucketn)
    except ClientError:
        bucket = s3.create_bucket(Bucket=bucketn)

def main():
    from pgbackup import pgdump, storage

    args = create_parser().parse_args()
    dump = pgdump.dump(args.url)
    timestamp = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
    if args.driver == 's3':
        client = boto3.client('s3')
        create_bucket(args.destination)
        file_name = pgdump.dump_file_name(args.url, timestamp)
        print(f"Backing db up to {args.destination} in S3 as {file_name}")
        storage.s3(client, dump.stdout, args.destination, file_name)
    else:
        file_name = pgdump.dump_file_name(args.destination, timestamp)
        print(f"Backing db up locally as {file_name}")
        outfile = open(file_name, 'wb')
        storage.local(dump.stdout, outfile)

